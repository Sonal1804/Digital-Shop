from django.db import models

# Create your models here.


class Product(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    price = models.IntegerField(default=0)
    discount = models.IntegerField(default=0)
    active = models.BooleanField(default=True)
    files = models.FileField(upload_to='uploads/files', null=True, blank=True)
    thumbnail = models.ImageField(upload_to='uploads/thumbnails',)
    link = models.CharField(max_length=200, null=True, blank=True)
    fileSize = models.CharField(max_length=50, null=True)


class ProductImages(models.Model):
    product_id = models.ForeignKey(
        Product, default=None, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='uploads/images', blank=True)


class User(models.Model):
    name = models.CharField(max_length=50)
    active = models.BooleanField(default=True)
    email = models.CharField(max_length=300, unique=True)
    password = models.CharField(max_length=500)
    phone = models.CharField(max_length=10)

class Payment(models.Model):
    product=models.ForeignKey(Product, null=False, on_delete=models.CASCADE)
    user=models.ForeignKey(User, null=False,on_delete=models.CASCADE)
    payment_request_id=models.CharField(max_length=200, null=False, unique=True)
    payment_id=models.CharField(max_length=200, unique=False)
    created_at=models.DateTimeField(auto_now_add=True)
    status=models.CharField(max_length=100, default='Failed')
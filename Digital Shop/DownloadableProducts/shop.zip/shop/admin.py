from django.contrib import admin
from . models import Product, ProductImages, User, Payment
from django.utils.html import format_html

# Register your models here.


class ProductImagesModel(admin.StackedInline):
    model = ProductImages


class ProductModel(admin.ModelAdmin):
    list_display = ['name', 'get_description', 'get_price',
                    'get_discount', 'get_sale_price', 'thumbnail']
    inlines = [ProductImagesModel]

    def get_description(self, obj):
        return format_html(f'<span title="{obj.description}">{obj.description[0:15]}...</span')

    def get_sale_price(self, obj):
        return ('₹ ' + str((obj.price) - (obj.price * (obj.discount/100))))

    def get_price(self, obj):
        return '₹ '+str(obj.price)

    def get_discount(self, obj):
        return str(obj.discount) + '%'

    get_description.short_description = 'Description'
    get_price.short_description = 'Price'
    get_discount.short_description = 'Discount'
    get_sale_price.short_description = 'Sale Price'


admin.site.register(Product, ProductModel)
admin.site.register(User)
admin.site.register(Payment)

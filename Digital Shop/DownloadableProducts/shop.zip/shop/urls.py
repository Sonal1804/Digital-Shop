from django.contrib import admin
from django.urls import path
# from . views import index,login;
from . import views as v
from .class_view.login import LoginView
from .class_view.signup import SignView
from .class_view.email_verification import sendotp,verifyotp
from .class_view.getClickProductDetail import get_clicked_product_details
from .class_view.download import downloadfree , downloadPaidProduct
from .class_view.payment import createpayment, verifypayment
from .middlewares.login_required_middleware import login_required

urlpatterns = [
    # path('admin/', admin.site.urls),

    path('', v.index, name='index'),
    path('logout',v.logout,name='logout'),
    path('login', LoginView.as_view(), name='login'),
    path('get_clicked_product_details/<int:product_id>',get_clicked_product_details, name='productDetail'),
    path('downloadfree/<int:product_id>',downloadfree,name='downloadfree'),
    path('signup', SignView.as_view(), name='signup'),
    path('send-otp', sendotp, name='sendotp'),
    path('verifyotp',verifyotp, name='verifyotp'),
    path('createpayment/<int:product_id>',login_required(createpayment) ,name='createpayment'),
    path('verifypayment',verifypayment,name='verifypayment'),
    path('download/paidproduct/<int:product_id>',login_required(downloadPaidProduct),name='downloadPaidProduct'),

]

from django.shortcuts import render,HttpResponse,redirect

def login_required(get_response):


# here get_Response is view class 
# middleware is we run one function before to start of another function

    def middleware(request,product_id=None):
        user=request.session.get('user')
        if user:
            if product_id:
                response=None
                response=get_response(request,product_id)
                return response
            else: 
                response=get_response(request)
                return response
        else:
            print("Please login")
            url=request.path
            print(url)
            return redirect(f'/login?return_url={url}')
    return middleware
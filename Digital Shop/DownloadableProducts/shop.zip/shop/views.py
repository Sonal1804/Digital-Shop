from django.shortcuts import render,HttpResponse,redirect
from  .models import Product, ProductImages, User
from .forms import UserForm
from django.contrib.auth.hashers import make_password, check_password
from .utils.email_sender import sendEmail
import random
import math
# Create your views here.

def index(request):
    # sendEmail(name="Sonal Misal", email="2017.sonal.misal@ves.ac.in", subject="testing", htmlContent="<h1>Testing msg you receive Successfully</h1>")
    product=Product.objects.filter(active=True)
    # print(product)
    data={'products':product}
    return render(request,'index.html',data)

def logout(request):
    request.session.clear()
    return redirect(index)












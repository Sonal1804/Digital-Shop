function init(){}

function changeImage(event){

    console.log(event.target.src);
    var thumbimg=document.getElementById("thumbimg");
    thumbimg.src=event.target.src;
}


window.onload=init;


var token;
var loadiing = null
window.onload = function () {
    loading = document.getElementById('loading')
}


function validate(event) {

    // console.log(event.target.elements.name);
    console.log("form submission");
    // var elements=event.target.elements;
    var form = event.target;
    var elements = form.elements

    var message = null;

    var email = elements.email.value;
    var name = elements.name.value;
    token = elements.csrfmiddlewaretoken.value;



    // console.log({name,phone,email,password,repassword});

    var error = document.getElementById("message")
    var message = null;


    message = validateform(form)
    if (message) {
        error.innerHTML = message;
        error.hidden = false;
    }
    else {
        error.hidden = true;


        // sendEmail and verify mail
        sendEmail(email, name, token)
    }



    event.stopPropagation();
    return false
}



function validateform(form) {

    var elements = form.elements
    var name = elements.name.value;
    var phone = elements.phone.value;
    var email = elements.email.value;
    var password = elements.password.value;
    var repassword = elements.repassword.value;
    token = elements.csrfmiddlewaretoken.value;



    // console.log({name,phone,email,password,repassword});

    var error = document.getElementById("message")
    var message = null;
    if (!name.trim()) {
        message = "Name is required"
    }
    else if (!email.trim()) {
        message = "Email is required"
    }
    else if (!password.trim()) {
        message = "Password is required"
    }
    else if (!repassword.trim()) {
        message = "Re-Enter Password is required"
    }
    else if (password.trim() != repassword.trim()) {
        message = "Password is not Matched"
    }

    return message

}



function sendEmail(email, name, token) {
    console.log(email, name, token)
    loading.hidden = false
    //alert()
    $.ajax({
        method: "POST",
        url: "/send-otp",
        data: { name: name, email: email, 'csrfmiddlewaretoken': token }
    })
        .done(function (msg) {

            loading.hidden = true
            showOtpInput()
            //    alert( "Data Saved: " + msg );
        })
        //    
        //   })
        .fail(function (err) {
            loading.hidden = true
            alert('Cant Send Email')
        });

}

function showOtpInput() {
    var otpnum = document.getElementById('otpnum')
    var btnsubmit = document.getElementById('btnsubmit')
    var btnverify = document.getElementById('btnverify')


    otpnum.hidden = false
    btnsubmit.hidden = true
    btnverify.hidden = false

}


function verifycode() {

    var code_id = document.getElementById("code")
    var otp = code_id.value;

    loading.hidden = false

    $.ajax({
        method: "POST",
        url: "verifyotp",
        data: { "otp": otp, 'csrfmiddlewaretoken': token }
    })
        .done(function (msg) {
            loading.hidden = true
            submitform()
        })
        //      
        //   })
        .fail(function (err) {
            loading.hidden = true
            alert('Cant Send Email')
        });

}


function submitform() {
    try {
        form = document.getElementById('form')

        responsemesssage = validateform(form)
        if (responsemesssage) {
            alert("invalid")
        }
        else {
            form.submit()
        }
    }

    catch (err) {
        console.log(err);
    }

}
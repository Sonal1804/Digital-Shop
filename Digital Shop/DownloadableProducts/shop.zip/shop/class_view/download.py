from django.shortcuts import render,HttpResponse,redirect
from  shop.models import Product, ProductImages, User, Payment

from django.contrib.auth.hashers import make_password, check_password
from shop.utils.email_sender import sendEmail
import random
import math
# Create your views here.

def downloadfree(request,product_id):
    try:
        product=Product.objects.get(id=product_id)
        if product.discount == 100:
            return redirect(product.files.url)
        else:
            return redirect('index')
    except:
        return redirect('index')

def downloadPaidProduct(request,product_id):
    product=Product.objects.get(id=product_id)
    session_user=request.session.get('user')
    user=User(id=session_user.get('id'))
    payment=Payment.objects.filter(user=user,product=product)
    return redirect(product.files.url)
    if (len(payment)==0):
        return redirect(product.files.url)
    else:
        return redirect('index')

from django.shortcuts import render,HttpResponse,redirect
from  shop.models import Product, ProductImages, User
from shop.forms import UserForm
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class LoginView(View):
    return_url=None
    def get(Self,request):
        print("class based view :get ")
        LoginView.return_url=request.GET.get('return_url')
        return render(request,'login.html')

    def post(self,request):
        email=request.POST.get('email')
        password=request.POST.get("password")

        try:
            user=User.objects.get(email=email)
            flag= check_password(password=password, encoded=user.password)

            #  print(user.__dict__) print(all the information store in user object . print as dict format)
            if flag:

                temp={}
                temp['id']=user.id
                temp['email']=user.email  
                request.session['user']=temp 
            
                if LoginView.return_url:
                    return redirect(LoginView.return_url)
                return redirect('index')
            else:
                return render(request,'signUp.html',{'error':'Invalid Username or Password...'})
        except:
            return render(request,"signUp.html",{'error':'Invalid Username or Password...'})
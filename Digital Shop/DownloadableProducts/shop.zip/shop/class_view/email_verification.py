from django.shortcuts import render,HttpResponse,redirect
from  shop.models import Product, ProductImages, User
from shop.forms import UserForm
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
import math
import random


def sendotp(request):
    name=request.POST.get('name')
    email=request.POST.get('email')
    otp=math.floor(random.random()*1000)
    htmlContent=f'''   
            <h4>Hello {name}, </h4>
            <p>Your verification code is : <b>{otp}</b></p>
            <p>If you didn't requested verification code, you can ignore this</p>    
        '''
    # # print(name,email)
    # # print('abc')
    if name and email:
        response=sendEmail(name=name,email=email,htmlContent=htmlContent,subject="Verified Successfully")

    try:
        if(response):
            request.session['verification_code']=otp
            return HttpResponse('{"message":"success"}',status=200)
        else:
            return HttpResponse(status=400)
    except:
        return HttpResponse(status=400)


def verifyotp(request):

    code=request.session.get('verification_code')
    otp=request.POST.get('otp')
    
    print(code,otp)

    if(str(code)==otp):
    
        return  HttpResponse('{"message":"success"}',status=200)
    
    else:
        return  HttpResponse(status=400)
    

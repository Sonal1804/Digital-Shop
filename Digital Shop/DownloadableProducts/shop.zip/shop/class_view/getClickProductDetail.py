from django.shortcuts import render,HttpResponse,redirect
from  shop.models import Product, ProductImages, User
from shop.forms import UserForm
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


def get_clicked_product_details(request,product_id):
    product_obj=Product.objects.get(id=product_id)
    productimg_obj=ProductImages.objects.filter(product_id=product_obj.id)
    return render(request,'getClickedProductDetials.html',{"product_obj":product_obj, "productimg_obj": productimg_obj})
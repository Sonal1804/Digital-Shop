from django.shortcuts import render,HttpResponse,redirect
from  shop.models import Product, ProductImages, User
from shop.forms import UserForm
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class SignView(View):
    def get(Self,request):
       return render(request,'signUp.html')

    def post(self,request):
        try:
            if (request.method=='POST'):
                name=request.POST.get('name')
                email=request.POST.get('email')
                password=request.POST.get('password')
                hashpassword=make_password(password=password)
                phone=request.POST.get('phone')
                print(request.POST)
                user=User(name=name,email=email,password=hashpassword,phone=phone)
                user.save()
                return render(request,'login.html')
        except:
            return render(request,'signUp.html',{'error':'User Already Registered...'})
        



from instamojo_wrapper import Instamojo
from DownloadableProducts.settings import PAYMENT_API_AUTH_TOKEN,PAYMENT_API_KEY
from django.shortcuts import render,HttpResponse,redirect
from  shop.models import Product, ProductImages, User, Payment
from shop.forms import UserForm
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
import math
 
API = Instamojo(api_key=PAYMENT_API_KEY, auth_token=PAYMENT_API_AUTH_TOKEN, endpoint='https://test.instamojo.com/api/1.1/')

def createpayment(request,product_id):

    product=Product.objects.get(id=product_id)
    user=request.session.get('user')
    userobj=User.objects.get(id=user.get('id'))
    amount=((product.price)-(product.price * (product.discount/100)))
    
    API = Instamojo(api_key=PAYMENT_API_KEY, auth_token=PAYMENT_API_AUTH_TOKEN, endpoint='https://test.instamojo.com/api/1.1/')

    response = API.payment_request_create(
        amount=math.floor(amount),
        purpose=f'Payent for {product.name}',
        send_email=True,
        email=user.get('email'),
        buyer_name=userobj.name,
        phone=userobj.phone,
        redirect_url="http://localhost:8000/verifypayment"
        )

    payment_request_id=response['payment_request']['id']

    payment=Payment(
        user=User(id=user.get('id')),
        product=product,
        payment_request_id=payment_request_id
    )
    payment.save()

    url=response['payment_request']['longurl']
    return redirect(url)

def verifypayment(request):
    print(request.GET)
    user=request.session.get('user')
    userobj=User.objects.get(id=user.get('id'))
    payment_request_id=request.GET.get('payment_request_id')
    payment_id=request.GET.get('payment_id')


    response = API.payment_request_payment_status(payment_request_id, payment_id)
    status=response['payment_request']['payment']['status']
    if status != 'Failed':
        payment=Payment.objects.get(payment_request_id=payment_request_id)
        payment.payment_id=response['payment_request']['payment']['payment_id']
        payment.status=status
        payment.save()
        return render(request,'DownloadProductAfterPayment.html',{'payment':payment})
    else:
        return render(request,'PaymentFailed.html')
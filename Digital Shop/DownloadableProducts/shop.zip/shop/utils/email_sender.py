import requests
from DownloadableProducts.settings import EMAIL_SERVICE_ENDPOINT, EMAIL_SENDER_NAME, EMIAL_SENDER_EMAIL, EMAIL_API_KEY

import  json



def sendEmail(name, email, subject, htmlContent):
    # payload = {
    #     "sender": {
    #         "name": EMAIL_SENDER_NAME,
    #         "email": EMIAL_SENDER_EMAIL
    #     },
    #     "to": [
    #         {
    #             "email": email,
    #             'name': name

    #         }
    #     ],
    #     'replyTo': {
    #         "email": EMIAL_SENDER_EMAIL,
    #         "name": EMAIL_SENDER_NAME
    #     },
    #     "htmlContent": htmlContent,
    #     'subject': subject
    # }

    # headers = {
    #     'accept': "application/json",
    #     'content-type': "application/json",
    #     'api-key': EMAIL_API_KEY
    # }

    # response = requests.request("POST",
    #                             EMAIL_SERVICE_ENDPOINT,
    #                             data=json.dumps(payload),
    #                             headers=headers)

    # return response

    response= requests.post(
	"https://api.mailgun.net/v3/sandboxbc9420be5e9f496c8515581d73d3f639.mailgun.org/messages",
 	auth=("api", "fa5d90e4bb880038dcff34417999acce-77751bfc-265a8cdb"),
 	data={"from": "Mailgun Sandbox <postmaster@sandboxbc9420be5e9f496c8515581d73d3f639.mailgun.org>",
 	"to": ["sonalmisal1804@gmail.com"],
 	"subject": subject,
 	"html": htmlContent})

    return response

# print(sendEmail("sonal","","Testing Email","<h1>Hello World</h1>"))
    

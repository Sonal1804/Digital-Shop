from instamojo_wrapper import Instamojo
from settings import PAYMENT_API_AUTH_TOKEN,PAYMENT_API_KEY

api = Instamojo(api_key=PAYMENT_API_KEY, auth_token=PAYMENT_API_AUTH_TOKEN, endpoint='https://test.instamojo.com/api/1.1/')

response = api.payment_request_create(
    amount='20',
    purpose='FOR TESTING',
    send_email=True,
    email="sonalmisal1804@gmail.com",
    redirect_url="http://www.example.com/handle_redirect.py"
    )

print(response['payment_request']['longurl'])